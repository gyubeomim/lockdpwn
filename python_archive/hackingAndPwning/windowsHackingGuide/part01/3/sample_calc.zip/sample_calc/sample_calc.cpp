#include "stdafx.h"

int sum(int a, int b){
	int result = 0;
	result = a+b;
	return result;
}

void _tmain(int argc, _TCHAR* argv[])
{
	int x = 9;
	int y = 4;
	int result = sum(x,y);
	if (result > 10){
		printf("Good!! Result : %d \n", result);
	} else {
		printf("Bad!! Result : %d \n", result);
	}
}

