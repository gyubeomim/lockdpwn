//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ToolBar.rc
//
#define IDI_ICON_00                     100
#define IDI_ICON_01                     101
#define IDI_ICON_02                     102
#define IDI_ICON_03                     103
#define IDI_ICON_04                     104
#define IDI_ICON_05                     105
#define IDI_ICON_06                     106
#define IDI_ICON_07                     107
#define IDI_ICON_08                     108
#define IDI_ICON_09                     109
#define IDI_ICON_10                     110
#define IDI_ICON_11                     111
#define IDI_ICON_12                     112
#define IDI_ICON_13                     113
#define IDI_ICON_14                     114
#define IDI_ICON_15                     115
#define IDI_ICON_16                     116
#define IDI_ICON_17                     117
#define IDI_ICON_18                     118
#define IDI_ICON_19                     119
#define IDI_ICON_20                     120
#define IDI_ICON_21                     121
#define IDI_ICON_22                     122
#define IDI_ICON_23                     123
#define IDI_ICON_24                     124
#define IDI_ICON_25                     125
#define IDI_ICON_26                     126
#define IDI_ICON_27                     127
#define IDI_ICON_28                     128
#define IDI_ICON_29                     129
#define IDI_ICON_30                     130
#define IDI_ICON_31                     131
#define IDI_ICON_32                     132
#define IDI_ICON_33                     133
#define IDI_ICON_34                     134
#define IDI_ICON_35                     135
#define IDI_ICON_36                     136
#define IDI_ICON_37                     137
#define IDI_ICON_38                     138
#define IDI_ICON_39                     139
#define IDI_ICON_40                     140
#define IDI_ICON_41                     141
#define IDI_ICON_42                     142
#define IDI_ICON_43                     143
#define IDI_ICON_44                     144
#define IDI_ICON_45                     145
#define IDI_ICON_46                     146
#define IDI_ICON_47                     147
#define IDI_ICON_48                     148
#define IDI_ICON_49                     149
#define IDI_ICON_50                     150
#define IDI_ICONARROW1                  500
#define IDI_ICONARROW2                  501
#define IDD_SETUP                       1001
#define IDC_TOOLBAR                     1101
#define IDC_TOOLBARTEXT                 1102
#define IDC_BIGICONS                    1103
#define IDC_FLATBUTTONS                 1104
#define IDC_16BIT                       1105
#define IDC_32BIT                       1106
#define IDC_SIDELEFT                    1107
#define IDC_SIDETOP                     1108
#define IDC_SIDERIGHT                   1109
#define IDC_SIDEBOTTOM                  1110
#define IDC_SIDE_LABEL                  1111
#define IDC_ROWS_LABEL                  1112
#define IDC_ROWS                        1113
#define IDM_SETUP                       1201
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        11001
#define _APS_NEXT_COMMAND_VALUE         12001
#define _APS_NEXT_CONTROL_VALUE         13006
#define _APS_NEXT_SYMED_VALUE           14001
#endif
#endif
