//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Macros.rc
//
#define IDI_ICON_PLUGIN                 101
#define IDI_ICON_RECORD                 102
#define IDI_ICON_STOP                   103
#define IDI_ICON_PLAY                   104
#define IDI_ICON_PLAYTOEND              105
#define IDI_ICON_STOPTOEND              106
#define IDD_MACROS                      1001
#define IDD_STOP                        1002
#define IDD_VIEW                        1003
#define IDC_MACROS_LABEL                1101
#define IDC_MACROS_LIST                 1102
#define IDC_PLAY                        1103
#define IDC_PLAY_X                      1104
#define IDC_REPEAT                      1105
#define IDC_REPEAT_SPIN                 1106
#define IDC_ACTIONS_GROUP               1107
#define IDC_RECORD                      1108
#define IDC_NAME                        1109
#define IDC_SAVE                        1110
#define IDC_DELETE                      1111
#define IDC_HOTKEY                      1112
#define IDC_ASSIGN                      1113
#define IDC_VIEW                        1114
#define IDC_CLOSE                       1115
#define IDC_STOP                        1201
#define IDC_SENDKEYS                    1301
#define IDC_EXPORT                      1302
#define IDC_KEYACT_LIST                 1303
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        11001
#define _APS_NEXT_COMMAND_VALUE         12001
#define _APS_NEXT_CONTROL_VALUE         13001
#define _APS_NEXT_SYMED_VALUE           14001
#endif
#endif
