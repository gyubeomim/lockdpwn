//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Sounds.rc
//
#define IDI_ICON_PLUGIN                 101
#define IDI_ICON_PLAY                   102
#define IDD_SETUP                       1001
#define IDD_ITEM                        1002
#define IDC_ENABLETHEME                 1101
#define IDC_LIST                        1102
#define IDC_DISABLEBEEP                 1103
#define IDC_ITEMADD                     1104
#define IDC_ITEMMODIFY                  1105
#define IDC_ITEMMOVEUP                  1106
#define IDC_ITEMMOVEDOWN                1107
#define IDC_ITEMDELETE                  1108
#define IDC_CLOSE                       1109
#define IDC_KEY_GROUP                   1201
#define IDC_KEYINPUT_CHECK              1202
#define IDC_KEYINPUT                    1203
#define IDC_KEYGROUP_MOVEMENT           1204
#define IDC_KEYGROUP_DIGITS             1205
#define IDC_KEYGROUP_CHARS              1206
#define IDC_FILE_GROUP                  1207
#define IDC_FILE_BROWSE                 1208
#define IDC_FILE_EDIT                   1209
#define IDC_FILE_PLAY                   1210
#define IDC_LAYOUT_GROUP                1211
#define IDC_LAYOUT_LIST                 1212
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        11001
#define _APS_NEXT_COMMAND_VALUE         12001
#define _APS_NEXT_CONTROL_VALUE         13001
#define _APS_NEXT_SYMED_VALUE           14001
#endif
#endif
