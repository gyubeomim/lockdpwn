//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Hotkeys.rc
//
#define IDI_ICON_PLUGIN                 101
#define IDD_MAIN                        1001
#define IDD_INPUTBOX                    1002
#define IDD_ALLKEYS                     1003
#define IDC_LIST                        1101
#define IDC_NAME_LABEL                  1102
#define IDC_NAME                        1103
#define IDC_COMMAND_LABEL               1104
#define IDC_COMMAND                     1105
#define IDC_HOTKEY_LABEL                1106
#define IDC_HOTKEYCODE                  1107
#define IDC_HOTKEY                      1108
#define IDC_BUTTONGROUP                 1109
#define IDC_ADDMODIFYHOTKEY             1110
#define IDC_ITEMRENAME                  1111
#define IDC_ITEMMOVEUP                  1112
#define IDC_ITEMMOVEDOWN                1113
#define IDC_ITEMDELETE                  1114
#define IDC_ALLKEYS                     1115
#define IDC_CLOSE                       1116
#define IDC_MAIN_FILTER                 1117
#define IDC_INPUTBOX_LABEL              1201
#define IDC_INPUTBOX_EDIT               1202
#define IDC_INPUTBOX_CHECK              1203
#define IDC_ALLKEYS_LIST                1301
#define IDC_ALLKEYS_ONLYASSIGNED        1302
#define IDC_ALLKEYS_FILTER              1303
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        11001
#define _APS_NEXT_COMMAND_VALUE         12001
#define _APS_NEXT_CONTROL_VALUE         13001
#define _APS_NEXT_SYMED_VALUE           14001
#endif
#endif
