//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SaveFile.rc
//
#define IDI_ICON_PLUGIN                 101
#define IDD_SETTINGS                    1001
#define IDD_RECOVER                     1002
#define IDC_AUTOSAVE_TITLE              1101
#define IDC_AUTOSAVE_MOMENT_GROUP       1102
#define IDC_AUTOSAVE_SAVEINTERVAL_CHECK 1103
#define IDC_AUTOSAVE_SAVEINTERVAL       1104
#define IDC_AUTOSAVE_MIN_LABEL          1105
#define IDC_AUTOSAVE_SAVEFOCUS_CHECK    1106
#define IDC_AUTOSAVE_SAVEFRAME_CHECK    1107
#define IDC_AUTOSAVE_METHOD_GROUP       1108
#define IDC_AUTOSAVE_SAVESIMPLE_CHECK   1109
#define IDC_AUTOSAVE_SAVENEAR_CHECK     1110
#define IDC_AUTOSAVE_SAVEDIR_CHECK      1111
#define IDC_AUTOSAVE_SAVEDIR            1112
#define IDC_AUTOSAVE_SAVEDIR_BROWSE     1113
#define IDC_AUTOSAVE_SAVEDIR_NOTE       1114
#define IDC_AUTOSAVE_TMPFILE_GROUP      1115
#define IDC_AUTOSAVE_TMPDELETE_CHECK    1116
#define IDC_AUTOSAVE_TMPTOBIN_CHECK     1117
#define IDC_AUTOSAVE_TMPRECOVER_CHECK   1118
#define IDC_SAVENOBOM_TITLE             1201
#define IDC_SAVENOBOM_GROUP             1202
#define IDC_SAVENOBOM_FORCE_RADIO       1203
#define IDC_SAVENOBOM_DLGUNCHECK_RADIO  1204
#define IDC_SAVENOBOM_UTF8              1205
#define IDC_SAVENOBOM_UTF16LE           1206
#define IDC_SAVENOBOM_UTF16BE           1207
#define IDC_SAVENOBOM_UTF32LE           1208
#define IDC_SAVENOBOM_UTF32BE           1209
#define IDC_RECOVER_LABEL               2001
#define IDC_RECOVER_LIST                2002
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        11001
#define _APS_NEXT_COMMAND_VALUE         12001
#define _APS_NEXT_CONTROL_VALUE         13001
#define _APS_NEXT_SYMED_VALUE           14001
#endif
#endif
