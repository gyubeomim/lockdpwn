//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Scripts.rc
//
#define IDL_TYPELIB                     1
#define IDI_ICON_PLUGIN                 101
#define IDD_SCRIPTS                     1101
#define IDD_COLUMNS                     1102
#define IDD_INPUTBOX                    1103
#define IDD_CODE                        1104
#define IDC_SCRIPTS_LIST                1201
#define IDC_SCRIPTS_FILTER              1202
#define IDC_SCRIPTS_OPENSITE            1203
#define IDC_SCRIPTS_COPYNAME            1204
#define IDC_CHANGELIST_GROUP            1205
#define IDC_EXEC                        1206
#define IDC_EDIT                        1207
#define IDC_HOTKEY_LABEL                1208
#define IDC_HOTKEY                      1209
#define IDC_ASSIGN                      1210
#define IDC_DEBUG_GROUP                 1211
#define IDC_DEBUG_JIT_CHECK             1212
#define IDC_DEBUG_JITFROMSTART_CHECK    1213
#define IDC_DEBUG_CODE_CHECK            1214
#define IDC_DEBUG_CODE_BUTTON           1215
#define IDC_CLOSE                       1216
#define IDC_INPUTBOX_LABEL              1301
#define IDC_INPUTBOX_EDIT               1302
#define IDC_COLUMNS_LIST                1401
#define IDC_COLUMNS_BUFFER_LABEL        1402
#define IDC_COLUMNS_BUFFER_EDIT         1403
#define IDC_COLUMNS_BUFFER_SPIN         1404
#define IDC_COLUMNS_ITEMMOVEUP          1405
#define IDC_COLUMNS_ITEMMOVEDOWN        1406
#define IDC_CODE_MEMREAD_STATIC         1501
#define IDC_CODE_MEMREAD_CHECK          1502
#define IDC_CODE_MEMWRITE_STATIC        1503
#define IDC_CODE_MEMWRITE_CHECK         1504
#define IDC_CODE_MEMFREE_STATIC         1505
#define IDC_CODE_MEMFREE_CHECK          1506
#define IDC_CODE_MEMLEAK_STATIC         1507
#define IDC_CODE_MEMLEAK_CHECK          1508
#define IDC_CODE_SYSCALL_STATIC         1509
#define IDC_CODE_SYSCALL_CHECK          1510
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        11001
#define _APS_NEXT_COMMAND_VALUE         12001
#define _APS_NEXT_CONTROL_VALUE         13001
#define _APS_NEXT_SYMED_VALUE           14001
#endif
#endif
