//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SpecialChar.rc
//
#define IDI_ICON_PLUGIN                 101
#define IDD_SETUP                       1001
#define IDC_LIST                        1101
#define IDC_NAME_LABEL                  1102
#define IDC_NAME_EDIT                   1103
#define IDC_ADDMODIFY_BUTTON            1104
#define IDC_DELETE_BUTTON               1105
#define IDC_OLDCHAR_GROUP               1106
#define IDC_OLDCHARHEX_RADIO            1107
#define IDC_OLDCHARHEXPREFIX_LABEL      1108
#define IDC_OLDCHARHEX_EDIT             1109
#define IDC_OLDCHARHEX_PREVIEW          1110
#define IDC_OLDCHARSPECIAL_RADIO        1111
#define IDC_OLDCHARSPECIAL_COMBO        1112
#define IDC_SOLIDINDENTLINE_CHECK       1113
#define IDC_NEWCHAR_GROUP               1114
#define IDC_NEWCHARHEX_LABEL            1115
#define IDC_NEWCHARHEXPREFIX_LABEL      1116
#define IDC_NEWCHARHEX_EDIT             1117
#define IDC_NEWCHARHEX_PREVIEW          1118
#define IDC_NEWCHARBASICTEXT_CHECK      1119
#define IDC_NEWCHARBASICTEXTCUSTOM_RADIO 1120
#define IDC_NEWCHARBASICTEXTDEFAULT_RADIO 1121
#define IDC_NEWCHARBASICTEXTCUSTOM_BUTTON 1122
#define IDC_NEWCHARSELTEXT_CHECK        1123
#define IDC_NEWCHARSELTEXTCUSTOM_RADIO  1124
#define IDC_NEWCHARSELTEXTDEFAULT_RADIO 1125
#define IDC_NEWCHARSELTEXTCUSTOM_BUTTON 1126
#define IDC_NEWCHARFONTSTYLE_LABEL      1127
#define IDC_NEWCHARFONTSTYLE_COMBO      1128
#define IDC_CODERTHEME_CHECK            1129
#define IDC_INDENTLINESIZE_EDIT         3609
#define IDC_INDENTLINESIZE_SPIN         3610
#define IDC_INDENTLINESIZE_LABEL        -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        11001
#define _APS_NEXT_COMMAND_VALUE         12001
#define _APS_NEXT_CONTROL_VALUE         13001
#define _APS_NEXT_SYMED_VALUE           14001
#endif
#endif
