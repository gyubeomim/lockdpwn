//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by RecentFiles.rc
//
#define IDI_ICON_PLUGIN                 101
#define IDI_ICON_OPEN                   102
#define IDI_ICON_MOVEUP                 103
#define IDI_ICON_MOVEDOWN               104
#define IDI_ICON_SORT                   105
#define IDI_ICON_DELETE                 106
#define IDI_ICON_DELETEOLD              107
#define IDD_RECENTFILESLIST             1001
#define IDC_ITEM_LIST                   1101
#define IDC_ITEM_STATS                  1102
#define IDC_SEARCH                      1103
#define IDC_ITEM_OPEN                   1104
#define IDC_ITEM_MOVEUP                 1105
#define IDC_ITEM_MOVEDOWN               1106
#define IDC_ITEM_SORT                   1107
#define IDC_ITEM_DELETE                 1108
#define IDC_ITEM_DELETEOLD              1109
#define IDC_ONLYNAMES                   1110
#define IDC_TOOLBAR                     1201

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        11001
#define _APS_NEXT_COMMAND_VALUE         12001
#define _APS_NEXT_CONTROL_VALUE         13001
#define _APS_NEXT_SYMED_VALUE           14001
#endif
#endif
