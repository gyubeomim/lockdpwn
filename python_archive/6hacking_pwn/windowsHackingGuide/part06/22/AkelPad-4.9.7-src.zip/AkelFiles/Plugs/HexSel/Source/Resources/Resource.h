//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by HexSel.rc
//
#define IDI_ICON_PLUGIN                 101
#define IDD_HEXSEL                      1001
#define IDD_SETUP                       1002
#define IDC_TITLETEXT                   1101
#define IDC_HEXVIEW                     1102
#define IDC_CLOSE                       1103
#define IDC_SETUP_DIRECTION_LABEL       1201
#define IDC_SETUP_DIRECTION_AUTO        1202
#define IDC_SETUP_DIRECTION_STR2HEX     1203
#define IDC_SETUP_DIRECTION_HEX2STR     1204
#define IDC_SETUP_ENCLOSE_LABEL         1205
#define IDC_SETUP_PREFIX_LABEL          1206
#define IDC_SETUP_PREFIX                1207
#define IDC_SETUP_SUFFIX_LABEL          1208
#define IDC_SETUP_SUFFIX                1209
#define IDC_SETUP_SINGLEBYTE_LABEL      1210
#define IDC_SETUP_SINGLEBYTE_AUTO       1211
#define IDC_SETUP_SINGLEBYTE_MANUAL     1212
#define IDC_SETUP_SINGLEBYTE_LIST       1213
#define IDC_SETUP_DOUBLEBYTE_LABEL      1214
#define IDC_SETUP_DOUBLEBYTE_UTF16LE    1215
#define IDC_SETUP_DOUBLEBYTE_UTF16BE    1216
#define IDC_SETUP_RADIX_LABEL           1217
#define IDC_SETUP_RADIXHEX              1218
#define IDC_SETUP_RADIXDEC              1219
#define IDC_SETUP_RADIXOCT              1220
#define IDM_SETUP                       2001
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        11001
#define _APS_NEXT_COMMAND_VALUE         12001
#define _APS_NEXT_CONTROL_VALUE         13001
#define _APS_NEXT_SYMED_VALUE           14001
#endif
#endif
