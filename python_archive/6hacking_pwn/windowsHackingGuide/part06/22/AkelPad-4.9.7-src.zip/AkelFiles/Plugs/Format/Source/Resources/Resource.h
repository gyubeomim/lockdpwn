//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Format.rc
//
#define IDI_ICON_00                     100
#define IDI_ICON_01                     101
#define IDI_ICON_02                     102
#define IDI_ICON_03                     103
#define IDD_ENCRYPT                     1001
#define IDD_DECRYPT                     1002
#define IDC_GROUP_LABEL                 1101
#define IDC_PASS1_LABEL                 1102
#define IDC_PASS1                       1103
#define IDC_PASS2_LABEL                 1104
#define IDC_PASS2                       1105
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        11001
#define _APS_NEXT_COMMAND_VALUE         12001
#define _APS_NEXT_CONTROL_VALUE         13001
#define _APS_NEXT_SYMED_VALUE           14001
#endif
#endif
