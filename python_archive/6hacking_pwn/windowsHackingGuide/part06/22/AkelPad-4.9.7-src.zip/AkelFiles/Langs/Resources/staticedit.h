// Add AkelEdit resources

#ifdef AKELEDIT_STATICBUILD
#define _MAC
#include "..\..\..\AkelEdit\Resources\resource.h"
#include "..\..\..\AkelEdit\Resources\AkelEdit.rc"
#endif
