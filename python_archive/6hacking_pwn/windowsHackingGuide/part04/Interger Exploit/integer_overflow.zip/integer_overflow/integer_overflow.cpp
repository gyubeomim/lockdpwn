#include "stdafx.h"
#include "string.h"
#include "stdlib.h"
/*
int main(int argc, char * argv[])
{
	unsigned int test = 4294967295;
	printf("unsigned int max : %u\n", test);
	printf("unsigned int max+2 : %u\n", test+2);
	return 0;
}
*/
int main(int argc, char * argv[])
{
	static char contents[400] = {0,};
	char len = 0;
	char buf[300] = {0,};
	if (argc != 2) { 
		printf("Usage : %s [filename]\n", argv[0]);
		exit(1);
	}
	FILE *f = fopen(argv[1], "r");
	fgets(contents,400,f);
	len = strlen(contents); 
	printf("Filename : %s \n", argv[1]);
	printf("len : %d\ncontents_len : %d\n", len, strlen(contents));
	if(len<300){
		memcpy(buf,contents,strlen(contents));
	}else{
		printf("Error!! Max Size:300\n");
		exit(1);
	}
}