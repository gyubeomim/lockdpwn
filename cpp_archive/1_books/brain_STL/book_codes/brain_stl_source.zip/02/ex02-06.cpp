#include <iostream>
using namespace std;

//////// ���� /////////////
void PrintHello( )
{
    cout << "Hello!" << endl;
}
/////// Ŭ���̾�Ʈ /////////
void main( )
{
    PrintHello( );
}