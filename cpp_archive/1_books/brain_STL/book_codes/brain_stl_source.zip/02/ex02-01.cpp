#include <iostream>
using namespace std;

void main()
{
    int n = 10;
    int *pn = &n;
}