#include <iostream>
using namespace std;

void Print(int a, int b)
{
    cout << a << ", " << b << endl;
}
void main( )
{
    Print(10, 20);
}